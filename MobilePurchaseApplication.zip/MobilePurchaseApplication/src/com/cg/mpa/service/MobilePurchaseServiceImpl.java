package com.cg.mpa.service;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mpa.dao.MobileDao;
import com.cg.mpa.dao.PurchaseDetailsDao;
import com.cg.mpa.entities.Mobile;
import com.cg.mpa.entities.PurchaseDetails;

@Transactional
@Service("mser")
public class MobilePurchaseServiceImpl implements MobilePurchaseService
{
	@Autowired
	MobileDao mdao;
	@Autowired
	PurchaseDetailsDao pdao;
	public List<Mobile> getAllMobiles()
	{
		return mdao.fetchAllMobiles();
	}
	
	@Override
	public void insertPurchaseDetails(PurchaseDetails pdetails)
	{
		pdao.insertPurchaseDetails(pdetails);
	}
}
