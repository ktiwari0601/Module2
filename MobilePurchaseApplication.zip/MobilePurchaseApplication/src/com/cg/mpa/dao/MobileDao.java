package com.cg.mpa.dao;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.mpa.entities.Mobile;

public interface MobileDao
{
	List<Mobile> fetchAllMobiles();
}
