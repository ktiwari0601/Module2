package com.cg.mpa.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.mpa.entities.Mobile;
import com.cg.mpa.entities.PurchaseDetails;

public interface PurchaseDetailsDao
{
	void insertPurchaseDetails(PurchaseDetails pdetails);
}
