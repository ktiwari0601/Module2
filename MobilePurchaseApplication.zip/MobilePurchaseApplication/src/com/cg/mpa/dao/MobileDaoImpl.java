package com.cg.mpa.dao;
import java.util.List;
import org.springframework.stereotype.Repository;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import com.cg.mpa.entities.Mobile;

@Repository
public class MobileDaoImpl implements MobileDao
{
	@PersistenceContext
	private EntityManager em;
	@Override
	public List<Mobile> fetchAllMobiles()
	{
		String jbql = "SELECT m FROM Mobile m";
		TypedQuery<Mobile> query = em.createQuery(jbql,Mobile.class);
				return query.getResultList();
	}
}
