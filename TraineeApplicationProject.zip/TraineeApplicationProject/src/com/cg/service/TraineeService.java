package com.cg.service;
import java.util.List;
import com.cg.entities.Trainee;

public interface TraineeService 
{
	void addTrainee(Trainee trainee);
	Trainee deleteTrainee(Integer traineeId);
	void modify(Trainee trainee);
	Trainee retrieveTrainee(Integer traineeId);
	List<Trainee> fetchAllTrainee();
}
